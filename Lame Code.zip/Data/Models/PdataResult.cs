﻿using System;
using System.Collections.Generic;

namespace SSRNMFSSN.Data.Models
{
    public partial class PdataResult
    {
        public int PdataResultId { get; set; }
        public string PdataResult1 { get; set; }
    }
}
