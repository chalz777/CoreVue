﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.AspNetCore.Authentication;

namespace Web.Security.Identity {
	public class AuthenticationOptions: AuthenticationSchemeOptions {

		public AuthenticationOptions() {
			
		}
	}
}
