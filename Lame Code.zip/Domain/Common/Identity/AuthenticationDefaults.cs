﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Web.Security.Identity {
	public static class AuthenticationDefaults {
		public const string AuthenticationScheme = "DrtAuthentication";
	}
}
