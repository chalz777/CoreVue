﻿using System;
using System.Collections.Generic;

namespace SSRNMFSSN.Data.Models
{
    public partial class MdataResult
    {
        public int MdataResultId { get; set; }
        public string MdataResult1 { get; set; }
    }
}
