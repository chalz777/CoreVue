﻿namespace Web.Services.Mailer
{
    public class MailFactory
    {
        
    }
}
