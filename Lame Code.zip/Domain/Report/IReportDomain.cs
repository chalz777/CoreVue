﻿using SSRNMFSSN.Data.Models;
using System.Collections.Generic;

namespace SSRNMFSSN.Domain
{
    public interface IReportDomain
    {
    }
}
