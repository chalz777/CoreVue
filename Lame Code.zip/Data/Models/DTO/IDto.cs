﻿namespace SSRNMFSSN.Data.Models.DTO
{
    public interface IDto
    {
    }
}