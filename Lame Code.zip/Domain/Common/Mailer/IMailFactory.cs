﻿namespace Web.Services.Mailer
{
    public interface IMailFactory
    {
        
    }
}
